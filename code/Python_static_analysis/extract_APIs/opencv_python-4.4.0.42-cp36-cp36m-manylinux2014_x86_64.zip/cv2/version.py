opencv_version = "4.4.0.42"
contrib = False
headless = False
ci_build = True